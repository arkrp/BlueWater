import {createVendiaClient} from "@vendia/client";

const client = createVendiaClient({
    apiUrl: `https://supxejqaji.execute-api.us-west-2.amazonaws.com/graphql/`,
    websocketUrl: `wss://ek9oskdd9h.execute-api.us-west-2.amazonaws.com/graphql`,
    apiKey:`Fd3R1DjE4tsbUKZckFBPj2TsHDuodgxGQuyJpdnNrfk`, 
  })


export default useBavaria;